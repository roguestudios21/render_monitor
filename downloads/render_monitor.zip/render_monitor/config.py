ADDON_VERSION = "1.0.1"

BACKEND_URL = "https://rendermonitor-backend-792858946221.us-central1.run.app"
SIGNED_URLS_URL = f"{BACKEND_URL}/api/request_signed_urls"
BACKEND_PATCH_URL = f"{BACKEND_URL}/api/patch_metadata"
DEVICE_CODE_REQUEST_URL = f"{BACKEND_URL}/api/device_code/request"
DEVICE_CODE_POLL_URL = f"{BACKEND_URL}/api/device_code/poll"
USER_IS_PRO_URL = f"{BACKEND_URL}/api/user_is_pro"

LINK_DATA_FILENAME = "render_monitor_link.json"

# Local cache for signed URLs
SIGNED_URL_CACHE = {}

