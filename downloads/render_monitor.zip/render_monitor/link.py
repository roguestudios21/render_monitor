import bpy, os, json, requests
from . import config, networking, handlers

def get_link_data_path():
    config_dir = bpy.utils.user_resource('CONFIG')
    return os.path.join(config_dir, config.LINK_DATA_FILENAME)


def save_link_data(props):
    data = {
        "device_code": props.device_code,
        "session_token": props.session_token,
        "is_pro_user": props.is_pro_user,
    }
    try:
        with open(get_link_data_path(), "w") as f:
            json.dump(data, f)
    except Exception as e:
        print(f"[Add-on ERROR] Failed to save link data: {e}")


def load_link_data(props):
    try:
        with open(get_link_data_path(), "r") as f:
            data = json.load(f)
        props.device_code = data.get("device_code", "")
        props.session_token = data.get("session_token", "")
        props.is_pro_user = data.get("is_pro_user", False)
        if props.session_token:
            props.link_status = "Linked (auto-loaded)"
    except Exception:
        pass


class RENDERMONITOR_OT_LinkDevice(bpy.types.Operator):
    bl_idname = "render_monitor.link_device"
    bl_label = "Request Link Code"

    def execute(self, context):
        try:
            resp = requests.post(config.DEVICE_CODE_REQUEST_URL)
            resp.raise_for_status()
            code_info = resp.json()
            props = context.scene.render_monitor_props
            props.device_code = code_info["code"]
            props.link_status = "Waiting for link..."
            props.session_token = ""
            props.is_pro_user = False
            props.loaded_link_data = True
            save_link_data(props)
            self.report({"INFO"}, f"Device code: {props.device_code}")
        except Exception as e:
            self.report({"ERROR"}, f"Failed to get device code: {e}")
        return {"FINISHED"}


class RENDERMONITOR_OT_PollCode(bpy.types.Operator):
    bl_idname = "render_monitor.poll_code"
    bl_label = "Poll for Link Status"

    def execute(self, context):
        props = context.scene.render_monitor_props
        code = props.device_code.strip()
        if not code:
            self.report({"ERROR"}, "No device code found.")
            return {"CANCELLED"}
        try:
            resp = requests.get(config.DEVICE_CODE_POLL_URL, params={"code": code})
            resp.raise_for_status()
            data = resp.json()
            if data.get("linked"):
                props.session_token = data["session_token"]
                props.is_pro_user = networking.fetch_pro_status(props.session_token)
                props.link_status = f"Linked as {data.get('user_id', 'UNKNOWN')} - {'Pro' if props.is_pro_user else 'Basic'}"
                props.device_code = ""
                props.loaded_link_data = True
                save_link_data(props)
                self.report({"INFO"}, "Device successfully linked!")
            else:
                props.link_status = "Waiting for link..."
                self.report({"INFO"}, "Not linked yet. Try again.")
        except Exception as e:
            self.report({"ERROR"}, f"Polling failed: {e}")
        return {"FINISHED"}


class RENDERMONITOR_OT_ClearLink(bpy.types.Operator):
    bl_idname = "render_monitor.clear_link"
    bl_label = "Clear Linkage"

    def execute(self, context):
        props = context.scene.render_monitor_props
        props.device_code = ""
        props.session_token = ""
        props.link_status = "Not linked"
        props.is_pro_user = False
        props.loaded_link_data = True
        save_link_data(props)
        self.report({"INFO"}, "Device link cleared.")
        return {"FINISHED"}


class RENDERMONITOR_OT_RefreshHandlers(bpy.types.Operator):
    bl_idname = "render_monitor.refresh_handlers"
    bl_label = "Refresh Handlers"

    def execute(self, context):
        try:
            handlers.register_handlers()
            self.report({"INFO"}, "Render Monitor handlers refreshed")
        except Exception as e:
            self.report({"ERROR"}, f"Failed to refresh: {e}")
        return {"FINISHED"}

