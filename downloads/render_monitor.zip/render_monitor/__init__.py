bl_info = {
    "name": "Render Monitor",
    "author": "Atharv",
    "version": (1, 0, 1),
    "blender": (2, 80, 0),
    "location": "Properties > Render",
    "description": "Monitor render jobs and upload metadata and frames",
    "category": "Render",
}

import bpy
from . import props, panel, link, handlers

classes = (
    props.RenderMonitorProperties,
    panel.RENDERMONITOR_PT_panel,
    link.RENDERMONITOR_OT_LinkDevice,
    link.RENDERMONITOR_OT_PollCode,
    link.RENDERMONITOR_OT_ClearLink,
    link.RENDERMONITOR_OT_RefreshHandlers,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.render_monitor_props = bpy.props.PointerProperty(
        type=props.RenderMonitorProperties
    )
    handlers.register_handlers()
    print("[Blender] RenderMonitor add-on registered.")


def unregister():
    handlers.unregister_handlers()
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.render_monitor_props
    print("[Blender] RenderMonitor add-on unregistered.")

