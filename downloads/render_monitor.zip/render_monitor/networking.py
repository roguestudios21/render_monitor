import requests, os, time, bpy
from datetime import datetime
from . import config

def get_auth_headers():
    props = bpy.context.scene.render_monitor_props
    token = props.session_token.strip()
    if not token:
        raise RuntimeError("Device not linked.")
    return {
        "Authorization": f"Bearer {token}",
        "X-Addon-Version": config.ADDON_VERSION,
        "Content-Type": "application/json",
    }


def fetch_pro_status(session_token):
    headers = {
        "Authorization": f"Bearer {session_token}",
        "X-Addon-Version": config.ADDON_VERSION,
    }
    try:
        resp = requests.get(config.USER_IS_PRO_URL, headers=headers)
        resp.raise_for_status()
        return resp.json().get("isPro", False)
    except Exception as e:
        print(f"[Add-on ERROR] Failed to fetch Pro status: {e}")
        return False


def get_signed_upload_url(render_id, frame_number):
    key = (render_id, frame_number)
    if key in config.SIGNED_URL_CACHE:
        return config.SIGNED_URL_CACHE[key]

    headers = get_auth_headers()
    frames = list(range(frame_number, frame_number + 10))
    payload = {"render_id": render_id, "frames": frames}

    backoff = 0.5
    for _ in range(5):
        resp = requests.post(config.SIGNED_URLS_URL, json=payload, headers=headers)
        if resp.status_code == 429:
            retry_after = resp.headers.get("Retry-After")
            wait = float(retry_after) if retry_after else backoff
            print(f"[Add-on] 429. Retrying in {wait:.1f}s...")
            time.sleep(wait)
            backoff = min(backoff * 2, 8.0)
            continue
        resp.raise_for_status()
        data = resp.json()
        for f, url in data.get("urls", {}).items():
            config.SIGNED_URL_CACHE[(render_id, int(f))] = url
        break

    if key not in config.SIGNED_URL_CACHE:
        raise RuntimeError("Failed to obtain signed URL")
    return config.SIGNED_URL_CACHE[key]


def upload_frame_to_storage(filepath, signed_url):
    with open(filepath, "rb") as f:
        data = f.read()
    headers = {"Content-Type": "image/png"}
    r = requests.put(signed_url, headers=headers, data=data)
    if r.status_code in [200, 201]:
        print(f"[Storage] Uploaded {os.path.basename(filepath)} ✅")
    else:
        print(f"[Storage ERROR] {r.status_code} - {r.text}")


def patch_render_metadata(render_id, status, progress, current_frame, total_frames, resolution):
    headers = get_auth_headers()
    payload = {
        "render_id": render_id,
        "status": status,
        "progress": progress,
        "current_frame": current_frame,
        "total_frames": total_frames,
        "resolution": resolution,
    }
    try:
        resp = requests.post(config.BACKEND_PATCH_URL, json=payload, headers=headers)
        resp.raise_for_status()
        print(f"[Metadata] {status} progress {progress}% frame {current_frame}/{total_frames}")
    except Exception as e:
        print(f"[Metadata ERROR] {e}")


def convert_frame_to_png(input_filepath):
    try:
        img = bpy.data.images.load(input_filepath, check_existing=True)
    except Exception as e:
        print(f"[Add-on ERROR] Load failed: {e}")
        return None
    temp_dir = bpy.app.tempdir
    base = os.path.basename(input_filepath).rsplit('.', 1)[0]
    png_path = os.path.join(temp_dir, base + ".png")
    try:
        img.save_render(png_path)
    except Exception as e:
        print(f"[Add-on ERROR] Save PNG failed: {e}")
        bpy.data.images.remove(img)
        return None
    bpy.data.images.remove(img)
    return png_path

