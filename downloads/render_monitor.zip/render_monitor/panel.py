import bpy
from . import link

class RENDERMONITOR_PT_panel(bpy.types.Panel):
    bl_label = "Render Monitor"
    bl_idname = "RENDERMONITOR_PT_panel"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "render"

    def draw(self, context):
        layout = self.layout
        props = context.scene.render_monitor_props

        if not props.loaded_link_data:
            link.load_link_data(props)
            props.loaded_link_data = True

        layout.operator("render_monitor.link_device", text="Link Device (Get Code)")
        layout.label(text=f"Device Code: {props.device_code}")
        layout.label(text=f"Link Status: {props.link_status}")
        layout.label(text=f"User Tier: {'Pro' if props.is_pro_user else 'Basic'}")
        layout.operator("render_monitor.poll_code", text="Check Link Status")
        layout.operator("render_monitor.clear_link", text="Forget Link")
        layout.separator()
        layout.operator("render_monitor.refresh_handlers", text="Refresh")

