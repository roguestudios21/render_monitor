import bpy

class RenderMonitorProperties(bpy.types.PropertyGroup):
    device_code: bpy.props.StringProperty(name="Device Code")
    session_token: bpy.props.StringProperty(name="Session Token")
    link_status: bpy.props.StringProperty(name="Link Status")
    is_pro_user: bpy.props.BoolProperty(name="Is Pro User", default=False)
    loaded_link_data: bpy.props.BoolProperty(default=False)

