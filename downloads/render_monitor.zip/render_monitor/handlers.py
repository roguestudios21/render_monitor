import bpy, os
from datetime import datetime
from bpy.app.handlers import persistent
from . import networking, link, config

RENDER_ID = None


def handlers_registered():
    return (on_render_start in bpy.app.handlers.render_init and
            on_frame_write in bpy.app.handlers.render_write and
            on_render_complete in bpy.app.handlers.render_complete and
            on_render_cancel in bpy.app.handlers.render_cancel)


def on_render_start(scene):
    global RENDER_ID
    if not handlers_registered():
        register_handlers()

    props = scene.render_monitor_props
    if not props.session_token:
        link.load_link_data(props)
        props.loaded_link_data = True
    if not props.session_token:
        print("[Add-on ERROR] Device not linked.")
        return

    RENDER_ID = "render_" + datetime.now().strftime("%Y%m%d_%H%M%S")
    total_frames = scene.frame_end - scene.frame_start + 1
    resolution = f"{scene.render.resolution_x}x{scene.render.resolution_y}"
    networking.patch_render_metadata(RENDER_ID, "started", 0, scene.frame_start, total_frames, resolution)
    print(f"[Blender] Rendering started: {RENDER_ID}")


def on_frame_write(scene, depsgraph=None):
    global RENDER_ID
    props = scene.render_monitor_props
    if not props.session_token:
        link.load_link_data(props)
        props.loaded_link_data = True
    if not props.session_token:
        return

    current_frame = scene.frame_current
    start = scene.frame_start
    end = scene.frame_end
    progress = int((current_frame - start + 1) / (end - start + 1) * 100)
    total_frames = end - start + 1
    resolution = f"{scene.render.resolution_x}x{scene.render.resolution_y}"
    frame_filename = bpy.path.abspath(scene.render.frame_path(frame=current_frame))

    if os.path.exists(frame_filename):
        png_filename = networking.convert_frame_to_png(frame_filename)
        if png_filename and props.is_pro_user:
            try:
                signed_url = networking.get_signed_upload_url(RENDER_ID, current_frame)
                networking.upload_frame_to_storage(png_filename, signed_url)
            except Exception as e:
                print(f"[Upload ERROR] {e}")
    networking.patch_render_metadata(RENDER_ID, "rendering", progress, current_frame, total_frames, resolution)


def on_render_complete(scene):
    global RENDER_ID
    props = scene.render_monitor_props
    if not props.session_token:
        link.load_link_data(props)
        props.loaded_link_data = True
    if not props.session_token:
        return
    total_frames = scene.frame_end - scene.frame_start + 1
    resolution = f"{scene.render.resolution_x}x{scene.render.resolution_y}"
    networking.patch_render_metadata(RENDER_ID, "completed", 100, scene.frame_end, total_frames, resolution)
    print(f"[Blender] Render completed: {RENDER_ID}")


def on_render_cancel(scene):
    global RENDER_ID
    props = scene.render_monitor_props
    if not props.session_token:
        link.load_link_data(props)
        props.loaded_link_data = True
    if not props.session_token:
        return
    total_frames = scene.frame_end - scene.frame_start + 1
    resolution = f"{scene.render.resolution_x}x{scene.render.resolution_y}"
    networking.patch_render_metadata(RENDER_ID, "error", 0, scene.frame_current, total_frames, resolution)
    print(f"[Blender] Render canceled: {RENDER_ID}")


@persistent
def on_load_post(dummy):
    try:
        scene = bpy.context.scene
        if hasattr(scene, "render_monitor_props"):
            props = scene.render_monitor_props
            link.load_link_data(props)
            props.loaded_link_data = True
            register_handlers()
            if props.session_token:
                props.link_status = "Linked (auto-loaded)"
                try:
                    props.is_pro_user = networking.fetch_pro_status(props.session_token)
                    link.save_link_data(props)
                    props.link_status = f"Linked - {'Pro' if props.is_pro_user else 'Basic'}"
                except Exception as e:
                    print(f"[Add-on ERROR] Pro status refresh failed: {e}")
    except Exception as e:
        print(f"[Add-on ERROR] Load post failed: {e}")


def unregister_handlers():
    for h, lst in [
        (on_render_start, bpy.app.handlers.render_init),
        (on_frame_write, bpy.app.handlers.render_write),
        (on_render_complete, bpy.app.handlers.render_complete),
        (on_render_cancel, bpy.app.handlers.render_cancel),
        (on_load_post, bpy.app.handlers.load_post),
    ]:
        if h in lst:
            lst.remove(h)


def register_handlers():
    unregister_handlers()
    bpy.app.handlers.render_init.append(on_render_start)
    bpy.app.handlers.render_write.append(on_frame_write)
    bpy.app.handlers.render_complete.append(on_render_complete)
    bpy.app.handlers.render_cancel.append(on_render_cancel)
    if on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(on_load_post)

